using Microsoft.VisualStudio.TestTools.UnitTesting;
using OPG1Football;
using System;
using System.Collections.Generic;
using System.Text;

namespace FootballPlayerTests
{
    [TestClass]
    public class FootballPlayerTest
    {
        [TestInitialize]
        public void BeforeTest()
        {
            FootballPlayer footballPlayer = new FootballPlayer(1, "Mikkel", 20000, 14);
        }
        
        [TestMethod]
        public void NameTest()
        {
            FootballPlayer footballPlayer = new FootballPlayer(1, "Mikkel", 20000, 14);
            footballPlayer.Name = "Mikkel";
            Assert.AreEqual("Mikkel", footballPlayer.Name);

            //footballPlayer.Name = "Tim";
            //Assert.AreEqual("Tim", footballPlayer.Name);

            Assert.ThrowsException<ArgumentException>(() => footballPlayer.Name = "");
        }

        [TestMethod]
        public void PriceTest()
        {
            FootballPlayer footballPlayer = new FootballPlayer(1, "Mikkel", 20000, 14);
            footballPlayer.Price = 20000;
            Assert.AreEqual(20000, footballPlayer.Price);

            //footballPlayer.Price = 0;
            //Assert.AreEqual(0, footballPlayer.Price);

            Assert.ThrowsException<ArgumentOutOfRangeException>(() => footballPlayer.Price = -1 );
        }

        [TestMethod]
        public void ShirtNumberTest()
        {
            FootballPlayer footballPlayer = new FootballPlayer(1, "Mikkel", 20000, 14);
            footballPlayer.ShirtNumber = 14;
            Assert.AreEqual(14, footballPlayer.ShirtNumber);

            //footballPlayer.ShirtNumber = 0;
            //Assert.AreEqual(0, footballPlayer.ShirtNumber);

            //footballPlayer.ShirtNumber = 101;
            //Assert.AreEqual(101, footballPlayer.ShirtNumber);
        }

        [TestMethod()]
        public void ToStringTest()
        {

        }
    }
}
